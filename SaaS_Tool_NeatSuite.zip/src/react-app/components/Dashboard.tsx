import { useState } from 'react';
import { Calendar, Package, DollarSign, Users, TrendingUp, Calendar as CalendarIcon } from 'lucide-react';
import RevenueChart from '@/react-app/components/charts/RevenueChart';
import SalesChart from '@/react-app/components/charts/SalesChart';
import TopSellingProducts from '@/react-app/components/widgets/TopSellingProducts';
import RecentActivities from '@/react-app/components/widgets/RecentActivities';

const Dashboard = () => {
  const [timeframe, setTimeframe] = useState('month');
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-800">Dashboard</h1>
        <div className="flex space-x-2">
          <button 
            onClick={() => setTimeframe('week')}
            className={`px-3 py-1.5 rounded-lg text-sm ${
              timeframe === 'week' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            Week
          </button>
          <button 
            onClick={() => setTimeframe('month')}
            className={`px-3 py-1.5 rounded-lg text-sm ${
              timeframe === 'month' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            Month
          </button>
          <button 
            onClick={() => setTimeframe('quarter')}
            className={`px-3 py-1.5 rounded-lg text-sm ${
              timeframe === 'quarter' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            Quarter
          </button>
          <button 
            onClick={() => setTimeframe('year')}
            className={`px-3 py-1.5 rounded-lg text-sm ${
              timeframe === 'year' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            Year
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Revenue</p>
              <p className="text-2xl font-semibold">$84,254.48</p>
              <p className="text-sm text-green-600 flex items-center mt-1">
                <TrendingUp className="mr-1" size={16} />
                8.2% <span className="text-gray-500 ml-1">vs last {timeframe}</span>
              </p>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <DollarSign className="text-blue-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">New Orders</p>
              <p className="text-2xl font-semibold">384</p>
              <p className="text-sm text-green-600 flex items-center mt-1">
                <TrendingUp className="mr-1" size={16} />
                4.7% <span className="text-gray-500 ml-1">vs last {timeframe}</span>
              </p>
            </div>
            <div className="bg-indigo-100 p-3 rounded-full">
              <Package className="text-indigo-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Customers</p>
              <p className="text-2xl font-semibold">1,284</p>
              <p className="text-sm text-green-600 flex items-center mt-1">
                <TrendingUp className="mr-1" size={16} />
                12.2% <span className="text-gray-500 ml-1">vs last {timeframe}</span>
              </p>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <Users className="text-green-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Scheduled Demos</p>
              <p className="text-2xl font-semibold">24</p>
              <p className="text-sm text-yellow-600 flex items-center mt-1">
                <Calendar className="mr-1" size={16} />
                8 <span className="text-gray-500 ml-1">upcoming this week</span>
              </p>
            </div>
            <div className="bg-yellow-100 p-3 rounded-full">
              <CalendarIcon className="text-yellow-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-lg font-medium mb-4">Revenue Overview</h2>
          <RevenueChart timeframe={timeframe} />
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-lg font-medium mb-4">Sales by Category</h2>
          <SalesChart />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <TopSellingProducts />
        <RecentActivities />
      </div>
    </div>
  );
};

export default Dashboard;
