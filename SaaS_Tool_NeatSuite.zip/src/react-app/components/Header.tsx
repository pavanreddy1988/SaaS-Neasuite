import { FC } from 'react';
import { Search, Bell, PanelLeft, Cable } from 'lucide-react';

interface HeaderProps {
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (collapsed: boolean) => void;
  setShowIntegrations: (show: boolean) => void;
}

const Header: FC<HeaderProps> = ({ 
  sidebarCollapsed, 
  setSidebarCollapsed,
  setShowIntegrations
}) => {
  return (
    <header className="bg-white border-b border-gray-200 h-16 flex items-center px-4 justify-between">
      <div className="flex items-center">
        <button 
          className="mr-4 p-1.5 rounded-lg hover:bg-gray-100 lg:hidden"
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
        >
          <PanelLeft size={20} />
        </button>
        
        <div className="relative">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="search"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Search..."
          />
        </div>
      </div>
      
      <div className="flex items-center">
        <button 
          onClick={() => setShowIntegrations(true)}
          className="p-2 rounded-lg hover:bg-gray-100 mr-2 flex items-center text-gray-700"
        >
          <Cable size={18} />
          <span className="ml-2 hidden md:inline">Integrations</span>
        </button>
        
        <button className="p-2 rounded-lg hover:bg-gray-100 relative">
          <Bell size={20} />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </button>
      </div>
    </header>
  );
};

export default Header;
