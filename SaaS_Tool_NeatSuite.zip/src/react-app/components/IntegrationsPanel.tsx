import { FC } from 'react';
import { X, Plug2, Link2, CheckCircle2, AlertCircle } from 'lucide-react';

interface IntegrationsPanelProps {
  onClose: () => void;
}

const IntegrationsPanel: FC<IntegrationsPanelProps> = ({ onClose }) => {
  const integrations = [
    {
      id: 'salesforce',
      name: 'Salesforce CRM',
      description: 'Connect your Salesforce account to sync customer data',
      connected: true,
      icon: '📊',
      category: 'CRM',
    },
    {
      id: 'hubspot',
      name: 'HubSpot',
      description: 'Integrate marketing automation and CRM tools',
      connected: true,
      icon: '🔄',
      category: 'Marketing',
    },
    {
      id: 'mailchimp',
      name: 'Mailchimp',
      description: 'Sync customer lists and campaign data',
      connected: false,
      icon: '📧',
      category: 'Marketing',
    },
    {
      id: 'stripe',
      name: 'Stripe',
      description: 'Process payments and manage subscriptions',
      connected: true,
      icon: '💳',
      category: 'Finance',
    },
    {
      id: 'zapier',
      name: 'Zapier',
      description: 'Connect your apps and automate workflows',
      connected: false,
      icon: '⚡',
      category: 'Automation',
    },
    {
      id: 'slack',
      name: 'Slack',
      description: 'Get notifications and alerts in your workspace',
      connected: true,
      icon: '💬',
      category: 'Communication',
    },
    {
      id: 'shopify',
      name: 'Shopify',
      description: 'Sync inventory, orders, and customer data',
      connected: false,
      icon: '🛒',
      category: 'E-commerce',
    },
    {
      id: 'googleanalytics',
      name: 'Google Analytics',
      description: 'Track website traffic and user behavior',
      connected: true,
      icon: '📈',
      category: 'Analytics',
    },
  ];

  const categories = [...new Set(integrations.map(item => item.category))];

  return (
    <div className="fixed inset-y-0 right-0 w-96 bg-white shadow-lg border-l border-gray-200 z-10 overflow-y-auto">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <div className="flex items-center">
          <Plug2 className="mr-2" size={20} />
          <h2 className="text-lg font-medium">Integrations</h2>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg hover:bg-gray-100"
        >
          <X size={20} />
        </button>
      </div>
      
      <div className="p-4">
        <div className="relative mb-4">
          <input
            type="text"
            placeholder="Search integrations..."
            className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
            </svg>
          </div>
        </div>

        <div className="mb-4">
          <h3 className="font-medium mb-2">Categories</h3>
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <button 
                key={category} 
                className="px-3 py-1 text-sm rounded-full bg-gray-100 hover:bg-gray-200 text-gray-800"
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        
        <div className="space-y-4">
          {integrations.map((integration) => (
            <div key={integration.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-start">
                <div className="flex-shrink-0 text-2xl mr-3">{integration.icon}</div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <h3 className="font-medium">{integration.name}</h3>
                    <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-800">
                      {integration.category}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{integration.description}</p>
                </div>
              </div>
              
              <div className="mt-3 flex justify-between items-center">
                {integration.connected ? (
                  <div className="flex items-center text-sm text-green-600">
                    <CheckCircle2 size={16} className="mr-1" />
                    Connected
                  </div>
                ) : (
                  <div className="flex items-center text-sm text-gray-500">
                    <AlertCircle size={16} className="mr-1" />
                    Not connected
                  </div>
                )}
                
                <button className={`flex items-center text-sm px-3 py-1.5 rounded-lg ${
                  integration.connected 
                    ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' 
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}>
                  <Link2 size={16} className="mr-1" />
                  {integration.connected ? 'Manage' : 'Connect'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default IntegrationsPanel;
