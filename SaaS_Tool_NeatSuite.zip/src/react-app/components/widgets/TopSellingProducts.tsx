import { ArrowUp, ArrowDown } from 'lucide-react';

const TopSellingProducts = () => {
  const products = [
    {
      id: 1,
      name: 'Premium Wireless Headphones',
      category: 'Electronics',
      price: 149.99,
      sales: 328,
      trend: 'up',
      trendValue: 12.4,
    },
    {
      id: 2,
      name: 'Smart Fitness Tracker',
      category: 'Electronics',
      price: 89.99,
      sales: 287,
      trend: 'up',
      trendValue: 8.7,
    },
    {
      id: 3,
      name: 'Organic Cotton T-Shirt',
      category: 'Apparel',
      price: 29.99,
      sales: 256,
      trend: 'down',
      trendValue: 3.2,
    },
    {
      id: 4,
      name: 'Stainless Steel Water Bottle',
      category: 'Home Goods',
      price: 24.99,
      sales: 215,
      trend: 'up',
      trendValue: 5.8,
    },
    {
      id: 5,
      name: 'Wireless Charging Pad',
      category: 'Electronics',
      price: 34.99,
      sales: 198,
      trend: 'down',
      trendValue: 2.1,
    },
  ];

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-medium">Top Selling Products</h2>
        <button className="text-blue-600 text-sm hover:underline">
          View All
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full">
          <thead>
            <tr className="text-left text-xs text-gray-500 border-b">
              <th className="pb-2">Product</th>
              <th className="pb-2">Price</th>
              <th className="pb-2">Sales</th>
              <th className="pb-2">Trend</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {products.map((product) => (
              <tr key={product.id} className="text-sm text-gray-800">
                <td className="py-3">
                  <div>
                    <p className="font-medium">{product.name}</p>
                    <p className="text-xs text-gray-500">{product.category}</p>
                  </div>
                </td>
                <td className="py-3">${product.price}</td>
                <td className="py-3">{product.sales}</td>
                <td className="py-3">
                  <div className={`flex items-center ${product.trend === 'up' ? 'text-green-600' : 'text-red-500'}`}>
                    {product.trend === 'up' ? (
                      <ArrowUp size={16} className="mr-1" />
                    ) : (
                      <ArrowDown size={16} className="mr-1" />
                    )}
                    {product.trendValue}%
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TopSellingProducts;
