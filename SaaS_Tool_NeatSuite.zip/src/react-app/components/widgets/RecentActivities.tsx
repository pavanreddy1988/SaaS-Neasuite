import { Clock, User, FileText, Package, CreditCard } from 'lucide-react';

const RecentActivities = () => {
  const activities = [
    {
      id: 1,
      type: 'order',
      title: 'New order placed',
      description: 'Order #38294 - $432.38',
      time: '5 min ago',
      icon: <Package size={16} className="text-blue-600" />,
    },
    {
      id: 2,
      type: 'customer',
      title: 'New customer registered',
      description: 'John Robinson from Seattle',
      time: '12 min ago',
      icon: <User size={16} className="text-green-600" />,
    },
    {
      id: 3,
      type: 'invoice',
      title: 'Invoice generated',
      description: 'Invoice #10483 for Cloud Services',
      time: '35 min ago',
      icon: <FileText size={16} className="text-purple-600" />,
    },
    {
      id: 4,
      type: 'payment',
      title: 'Payment received',
      description: '$2,340.00 from TechCorp Inc.',
      time: '1 hour ago',
      icon: <CreditCard size={16} className="text-yellow-600" />,
    },
    {
      id: 5,
      type: 'order',
      title: 'Order shipped',
      description: 'Order #38204 to Madison Ave, NY',
      time: '2 hours ago',
      icon: <Package size={16} className="text-blue-600" />,
    },
  ];

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-medium">Recent Activities</h2>
        <button className="text-blue-600 text-sm hover:underline">
          View All
        </button>
      </div>
      
      <div className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex">
            <div className="mt-0.5 mr-3 flex-shrink-0 w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
              {activity.icon}
            </div>
            <div className="flex-1">
              <div className="flex justify-between">
                <p className="font-medium text-sm">{activity.title}</p>
                <div className="flex items-center text-xs text-gray-500">
                  <Clock size={12} className="mr-1" />
                  {activity.time}
                </div>
              </div>
              <p className="text-sm text-gray-600 mt-0.5">{activity.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentActivities;
