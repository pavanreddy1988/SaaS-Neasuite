import { FC } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface RevenueChartProps {
  timeframe: string;
}

const RevenueChart: FC<RevenueChartProps> = ({ timeframe }) => {
  // Generate mock data based on selected timeframe
  const generateData = () => {
    if (timeframe === 'week') {
      return [
        { name: 'Mon', revenue: 3200, expenses: 2400 },
        { name: 'Tue', revenue: 4500, expenses: 2800 },
        { name: 'Wed', revenue: 3800, expenses: 2600 },
        { name: 'Thu', revenue: 5000, expenses: 3200 },
        { name: 'Fri', revenue: 6000, expenses: 3400 },
        { name: 'Sat', revenue: 3500, expenses: 2000 },
        { name: 'Sun', revenue: 2800, expenses: 1800 },
      ];
    } else if (timeframe === 'month') {
      return [
        { name: 'Week 1', revenue: 15000, expenses: 10200 },
        { name: 'Week 2', revenue: 17800, expenses: 11500 },
        { name: 'Week 3', revenue: 22500, expenses: 14200 },
        { name: 'Week 4', revenue: 28800, expenses: 16800 },
      ];
    } else if (timeframe === 'quarter') {
      return [
        { name: 'Jan', revenue: 61000, expenses: 42000 },
        { name: 'Feb', revenue: 74000, expenses: 48000 },
        { name: 'Mar', revenue: 85000, expenses: 52000 },
      ];
    } else {
      return [
        { name: 'Q1', revenue: 220000, expenses: 142000 },
        { name: 'Q2', revenue: 285000, expenses: 165000 },
        { name: 'Q3', revenue: 312000, expenses: 178000 },
        { name: 'Q4', revenue: 378000, expenses: 203000 },
      ];
    }
  };

  const data = generateData();

  return (
    <ResponsiveContainer width="100%" height={300}>
      <AreaChart
        data={data}
        margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
      >
        <defs>
          <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8} />
            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="colorExpenses" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8} />
            <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis 
          dataKey="name" 
          tickLine={false} 
          axisLine={false} 
          tick={{ fill: '#6b7280', fontSize: 12 }}
        />
        <YAxis 
          tickLine={false}
          axisLine={false}
          tick={{ fill: '#6b7280', fontSize: 12 }}
          tickFormatter={value => `$${value.toLocaleString()}`}
        />
        <Tooltip 
          formatter={(value: number) => [`$${value.toLocaleString()}`, undefined]}
          labelStyle={{ fontWeight: 'bold' }}
        />
        <Area 
          type="monotone" 
          dataKey="revenue" 
          stroke="#3b82f6" 
          fillOpacity={1} 
          fill="url(#colorRevenue)" 
          name="Revenue"
        />
        <Area 
          type="monotone" 
          dataKey="expenses" 
          stroke="#ef4444" 
          fillOpacity={1} 
          fill="url(#colorExpenses)" 
          name="Expenses"
        />
      </AreaChart>
    </ResponsiveContainer>
  );
};

export default RevenueChart;
