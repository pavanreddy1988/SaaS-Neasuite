import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

const SalesChart = () => {
  const data = [
    { name: 'Electronics', value: 35 },
    { name: 'Apparel', value: 25 },
    { name: 'Home Goods', value: 15 },
    { name: 'Books', value: 10 },
    { name: 'Other', value: 15 },
  ];

  const COLORS = ['#3b82f6', '#a855f7', '#ec4899', '#f97316', '#64748b'];

  return (
    <ResponsiveContainer width="100%" height={270}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          innerRadius={60}
          outerRadius={90}
          paddingAngle={2}
          dataKey="value"
          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          labelLine={false}
        >
          {data.map((_, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Legend
          layout="horizontal"
          verticalAlign="bottom"
          align="center"
          wrapperStyle={{ fontSize: '12px', marginTop: '10px' }}
        />
        <Tooltip formatter={(value) => `${value}%`} />
      </PieChart>
    </ResponsiveContainer>
  );
};

export default SalesChart;
