import { DollarSign, Users, ShoppingCart, TrendingUp } from 'lucide-react';

const Sales = () => {
  const recentDeals = [
    { id: 1, company: 'TechCorp Inc.', contact: 'Sarah Johnson', value: 45000, stage: 'Negotiation', probability: 75 },
    { id: 2, company: 'Global Solutions', contact: 'Mike Chen', value: 32000, stage: 'Proposal', probability: 60 },
    { id: 3, company: 'StartUp Labs', contact: 'Emma Wilson', value: 28000, stage: 'Discovery', probability: 40 },
    { id: 4, company: 'Enterprise Co.', contact: 'John Davis', value: 67000, stage: 'Closing', probability: 90 },
    { id: 5, company: 'Innovation Hub', contact: 'Lisa Brown', value: 38000, stage: 'Qualified', probability: 50 },
  ];

  const salesTeam = [
    { id: 1, name: 'Alex Thompson', role: 'Senior Sales Rep', deals: 12, revenue: 145000, target: 200000 },
    { id: 2, name: 'Rachel Green', role: 'Sales Rep', deals: 8, revenue: 98000, target: 120000 },
    { id: 3, name: 'David Martinez', role: 'Sales Rep', deals: 10, revenue: 112000, target: 150000 },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-800">Sales</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Pipeline Value</p>
              <p className="text-2xl font-semibold">$210,000</p>
              <p className="text-sm text-green-600 flex items-center mt-1">
                <TrendingUp className="mr-1" size={16} />
                15.3% from last month
              </p>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <DollarSign className="text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Active Deals</p>
              <p className="text-2xl font-semibold">28</p>
              <p className="text-sm text-gray-500 mt-1">
                5 closing this week
              </p>
            </div>
            <div className="bg-purple-100 p-3 rounded-full">
              <ShoppingCart className="text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Win Rate</p>
              <p className="text-2xl font-semibold">68%</p>
              <p className="text-sm text-green-600 flex items-center mt-1">
                <TrendingUp className="mr-1" size={16} />
                4% improvement
              </p>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <TrendingUp className="text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">New Leads</p>
              <p className="text-2xl font-semibold">47</p>
              <p className="text-sm text-gray-500 mt-1">
                This week
              </p>
            </div>
            <div className="bg-orange-100 p-3 rounded-full">
              <Users className="text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium">Active Deals Pipeline</h2>
            <button className="text-blue-600 text-sm hover:underline">View All</button>
          </div>
          <div className="space-y-3">
            {recentDeals.map((deal) => (
              <div key={deal.id} className="p-3 border border-gray-200 rounded-lg hover:border-blue-300 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-medium">{deal.company}</h3>
                    <p className="text-sm text-gray-600">{deal.contact}</p>
                  </div>
                  <span className="text-lg font-semibold text-blue-600">${deal.value.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-700">{deal.stage}</span>
                  <span className="text-sm text-gray-600">{deal.probability}% probability</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium">Sales Team Performance</h2>
            <button className="text-blue-600 text-sm hover:underline">View Details</button>
          </div>
          <div className="space-y-4">
            {salesTeam.map((member) => (
              <div key={member.id} className="p-3 border border-gray-200 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-medium">{member.name}</h3>
                    <p className="text-sm text-gray-600">{member.role}</p>
                  </div>
                  <span className="text-sm font-semibold">{member.deals} deals</span>
                </div>
                <div className="mt-2">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Revenue Progress</span>
                    <span className="font-medium">${member.revenue.toLocaleString()} / ${member.target.toLocaleString()}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ width: `${(member.revenue / member.target) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sales;
