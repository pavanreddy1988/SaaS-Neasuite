import { DollarSign, TrendingUp, TrendingDown, FileText, CreditCard } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const Finance = () => {
  const monthlyData = [
    { month: 'Jan', revenue: 65000, expenses: 42000, profit: 23000 },
    { month: 'Feb', revenue: 72000, expenses: 45000, profit: 27000 },
    { month: 'Mar', revenue: 68000, expenses: 48000, profit: 20000 },
    { month: 'Apr', revenue: 85000, expenses: 52000, profit: 33000 },
    { month: 'May', revenue: 91000, expenses: 54000, profit: 37000 },
    { month: 'Jun', revenue: 88000, expenses: 51000, profit: 37000 },
  ];

  const invoices = [
    { id: 'INV-1043', client: 'TechCorp Inc.', amount: 12500, status: 'paid', date: '2025-11-15', dueDate: '2025-11-30' },
    { id: 'INV-1044', client: 'Global Solutions', amount: 8750, status: 'pending', date: '2025-11-14', dueDate: '2025-11-28' },
    { id: 'INV-1045', client: 'StartUp Labs', amount: 6200, status: 'overdue', date: '2025-10-28', dueDate: '2025-11-12' },
    { id: 'INV-1046', client: 'Enterprise Co.', amount: 15000, status: 'paid', date: '2025-11-13', dueDate: '2025-11-27' },
    { id: 'INV-1047', client: 'Innovation Hub', amount: 9400, status: 'pending', date: '2025-11-16', dueDate: '2025-12-01' },
  ];

  const expenses = [
    { id: 1, category: 'Payroll', amount: 32000, date: '2025-11-15', recurring: true },
    { id: 2, category: 'Cloud Services', amount: 3200, date: '2025-11-10', recurring: true },
    { id: 3, category: 'Marketing', amount: 5800, date: '2025-11-08', recurring: false },
    { id: 4, category: 'Office Rent', amount: 4500, date: '2025-11-01', recurring: true },
    { id: 5, category: 'Equipment', amount: 2100, date: '2025-11-12', recurring: false },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-700';
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      case 'overdue': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const totalRevenue = monthlyData.reduce((sum, m) => sum + m.revenue, 0);
  const totalExpenses = monthlyData.reduce((sum, m) => sum + m.expenses, 0);
  const totalProfit = totalRevenue - totalExpenses;
  const profitMargin = ((totalProfit / totalRevenue) * 100).toFixed(1);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-800">Finance</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Revenue</p>
              <p className="text-2xl font-semibold">${totalRevenue.toLocaleString()}</p>
              <p className="text-sm text-green-600 flex items-center mt-1">
                <TrendingUp className="mr-1" size={16} />
                12.4% growth
              </p>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <DollarSign className="text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Expenses</p>
              <p className="text-2xl font-semibold">${totalExpenses.toLocaleString()}</p>
              <p className="text-sm text-red-600 flex items-center mt-1">
                <TrendingUp className="mr-1" size={16} />
                5.2% increase
              </p>
            </div>
            <div className="bg-red-100 p-3 rounded-full">
              <TrendingDown className="text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Net Profit</p>
              <p className="text-2xl font-semibold text-green-600">${totalProfit.toLocaleString()}</p>
              <p className="text-sm text-gray-500 mt-1">
                {profitMargin}% margin
              </p>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <TrendingUp className="text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Pending Invoices</p>
              <p className="text-2xl font-semibold">{invoices.filter(i => i.status !== 'paid').length}</p>
              <p className="text-sm text-gray-500 mt-1">
                1 overdue
              </p>
            </div>
            <div className="bg-yellow-100 p-3 rounded-full">
              <FileText className="text-yellow-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <h2 className="text-lg font-medium mb-4">Financial Overview</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={monthlyData}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="month" tickLine={false} axisLine={false} />
            <YAxis tickLine={false} axisLine={false} tickFormatter={value => `$${value / 1000}k`} />
            <Tooltip formatter={(value: number) => `$${value.toLocaleString()}`} />
            <Legend />
            <Bar dataKey="revenue" fill="#3b82f6" name="Revenue" radius={[4, 4, 0, 0]} />
            <Bar dataKey="expenses" fill="#ef4444" name="Expenses" radius={[4, 4, 0, 0]} />
            <Bar dataKey="profit" fill="#10b981" name="Profit" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium">Recent Invoices</h2>
            <button className="text-blue-600 text-sm hover:underline">View All</button>
          </div>
          <div className="space-y-3">
            {invoices.map((invoice) => (
              <div key={invoice.id} className="p-3 border border-gray-200 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-medium">{invoice.id}</h3>
                    <p className="text-sm text-gray-600">{invoice.client}</p>
                  </div>
                  <span className="text-lg font-semibold">${invoice.amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(invoice.status)}`}>
                    {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
                  </span>
                  <span className="text-sm text-gray-600">Due: {invoice.dueDate}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium">Recent Expenses</h2>
            <button className="text-blue-600 text-sm hover:underline">View All</button>
          </div>
          <div className="space-y-3">
            {expenses.map((expense) => (
              <div key={expense.id} className="flex justify-between items-center p-3 border border-gray-200 rounded-lg">
                <div className="flex items-center">
                  <div className="bg-gray-100 p-2 rounded-full mr-3">
                    <CreditCard size={16} className="text-gray-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">{expense.category}</h3>
                    <p className="text-sm text-gray-600">{expense.date}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold">${expense.amount.toLocaleString()}</p>
                  {expense.recurring && (
                    <span className="text-xs text-blue-600">Recurring</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Finance;
