import { FileText, Download, Calendar, TrendingUp, BarChart3, PieChart } from 'lucide-react';

const Reports = () => {
  const availableReports = [
    {
      id: 1,
      name: 'Monthly Sales Report',
      description: 'Comprehensive overview of sales performance',
      category: 'Sales',
      lastGenerated: '2025-11-15',
      frequency: 'Monthly',
      icon: <BarChart3 size={20} />,
    },
    {
      id: 2,
      name: 'Inventory Status',
      description: 'Current stock levels and reorder alerts',
      category: 'Inventory',
      lastGenerated: '2025-11-17',
      frequency: 'Weekly',
      icon: <PieChart size={20} />,
    },
    {
      id: 3,
      name: 'Financial Summary',
      description: 'Revenue, expenses, and profit analysis',
      category: 'Finance',
      lastGenerated: '2025-11-16',
      frequency: 'Monthly',
      icon: <TrendingUp size={20} />,
    },
    {
      id: 4,
      name: 'Customer Analytics',
      description: 'Customer behavior and retention metrics',
      category: 'Sales',
      lastGenerated: '2025-11-14',
      frequency: 'Monthly',
      icon: <BarChart3 size={20} />,
    },
    {
      id: 5,
      name: 'Product Performance',
      description: 'Top sellers and product trends',
      category: 'Sales',
      lastGenerated: '2025-11-13',
      frequency: 'Weekly',
      icon: <PieChart size={20} />,
    },
    {
      id: 6,
      name: 'Cash Flow Statement',
      description: 'Detailed cash flow analysis',
      category: 'Finance',
      lastGenerated: '2025-11-12',
      frequency: 'Monthly',
      icon: <TrendingUp size={20} />,
    },
  ];

  const scheduledReports = [
    { id: 1, name: 'Weekly Sales Summary', nextRun: '2025-11-24', recipients: 'sales@company.com' },
    { id: 2, name: 'Monthly Financial Report', nextRun: '2025-12-01', recipients: 'finance@company.com' },
    { id: 3, name: 'Inventory Alerts', nextRun: '2025-11-20', recipients: 'operations@company.com' },
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Sales': return 'bg-blue-100 text-blue-700';
      case 'Finance': return 'bg-green-100 text-green-700';
      case 'Inventory': return 'bg-purple-100 text-purple-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-800">Reports</h1>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
          <FileText size={18} className="mr-2" />
          Create Custom Report
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Reports</p>
              <p className="text-2xl font-semibold">{availableReports.length}</p>
              <p className="text-sm text-gray-500 mt-1">Available</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <FileText className="text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Scheduled</p>
              <p className="text-2xl font-semibold">{scheduledReports.length}</p>
              <p className="text-sm text-gray-500 mt-1">Auto-generated</p>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <Calendar className="text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">This Month</p>
              <p className="text-2xl font-semibold">24</p>
              <p className="text-sm text-gray-500 mt-1">Generated</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-full">
              <BarChart3 className="text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Exports</p>
              <p className="text-2xl font-semibold">156</p>
              <p className="text-sm text-gray-500 mt-1">Downloads</p>
            </div>
            <div className="bg-orange-100 p-3 rounded-full">
              <Download className="text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <h2 className="text-lg font-medium mb-4">Available Reports</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {availableReports.map((report) => (
            <div key={report.id} className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div className="bg-blue-100 p-2 rounded-lg text-blue-600">
                  {report.icon}
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${getCategoryColor(report.category)}`}>
                  {report.category}
                </span>
              </div>
              <h3 className="font-medium mb-1">{report.name}</h3>
              <p className="text-sm text-gray-600 mb-3">{report.description}</p>
              <div className="flex justify-between items-center text-xs text-gray-500 mb-3">
                <span>Last: {report.lastGenerated}</span>
                <span>{report.frequency}</span>
              </div>
              <button className="w-full flex items-center justify-center px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
                <Download size={16} className="mr-2" />
                Generate Report
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-medium">Scheduled Reports</h2>
          <button className="text-blue-600 text-sm hover:underline">Manage Schedule</button>
        </div>
        <div className="space-y-3">
          {scheduledReports.map((report) => (
            <div key={report.id} className="flex justify-between items-center p-3 border border-gray-200 rounded-lg">
              <div className="flex items-center">
                <div className="bg-green-100 p-2 rounded-full mr-3">
                  <Calendar size={16} className="text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium">{report.name}</h3>
                  <p className="text-sm text-gray-600">Next run: {report.nextRun}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">{report.recipients}</p>
                <button className="text-blue-600 text-sm hover:underline">Edit</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Reports;
