import { User, Bell, Shield, Palette, Globe, CreditCard, Users, Database } from 'lucide-react';

const Settings = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-800">Settings</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <h2 className="font-medium mb-4">Settings Menu</h2>
            <nav className="space-y-1">
              {[
                { id: 'profile', name: 'Profile', icon: <User size={18} /> },
                { id: 'notifications', name: 'Notifications', icon: <Bell size={18} /> },
                { id: 'security', name: 'Security', icon: <Shield size={18} /> },
                { id: 'appearance', name: 'Appearance', icon: <Palette size={18} /> },
                { id: 'language', name: 'Language & Region', icon: <Globe size={18} /> },
                { id: 'billing', name: 'Billing', icon: <CreditCard size={18} /> },
                { id: 'team', name: 'Team', icon: <Users size={18} /> },
                { id: 'data', name: 'Data & Privacy', icon: <Database size={18} /> },
              ].map((item) => (
                <button
                  key={item.id}
                  className="w-full flex items-center px-3 py-2 text-left rounded-lg hover:bg-gray-50 text-gray-700"
                >
                  {item.icon}
                  <span className="ml-3">{item.name}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-medium mb-4">Profile Settings</h2>
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="h-20 w-20 rounded-full bg-blue-500 flex items-center justify-center text-white text-2xl font-semibold">
                  JS
                </div>
                <div>
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
                    Change Photo
                  </button>
                  <p className="text-sm text-gray-500 mt-1">JPG, PNG or GIF (max 2MB)</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                  <input
                    type="text"
                    defaultValue="John"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                  <input
                    type="text"
                    defaultValue="Smith"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  defaultValue="john.smith@company.com"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="tel"
                  defaultValue="+1 (555) 123-4567"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                <textarea
                  rows={3}
                  defaultValue="Enterprise software specialist with 10+ years of experience."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4 border-t">
                <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  Cancel
                </button>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                  Save Changes
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-medium mb-4">Notification Preferences</h2>
            <div className="space-y-4">
              {[
                { id: 'email_orders', label: 'Email notifications for new orders', checked: true },
                { id: 'email_customers', label: 'Email notifications for new customers', checked: true },
                { id: 'email_reports', label: 'Weekly report summaries', checked: false },
                { id: 'push_updates', label: 'Push notifications for system updates', checked: true },
                { id: 'push_alerts', label: 'Push notifications for critical alerts', checked: true },
              ].map((pref) => (
                <label key={pref.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                  <span className="text-sm">{pref.label}</span>
                  <input
                    type="checkbox"
                    defaultChecked={pref.checked}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                </label>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-medium mb-4">Security</h2>
            <div className="space-y-4">
              <div>
                <button className="w-full flex justify-between items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <span className="text-sm">Change Password</span>
                  <span className="text-blue-600 text-sm">Update</span>
                </button>
              </div>
              <div>
                <button className="w-full flex justify-between items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <span className="text-sm">Two-Factor Authentication</span>
                  <span className="text-gray-500 text-sm">Disabled</span>
                </button>
              </div>
              <div>
                <button className="w-full flex justify-between items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <span className="text-sm">Active Sessions</span>
                  <span className="text-gray-500 text-sm">3 devices</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
