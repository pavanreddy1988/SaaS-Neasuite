import { Package, AlertTriangle, TrendingDown, Clock, Search } from 'lucide-react';

const Inventory = () => {
  const products = [
    { id: 1, name: 'Premium Wireless Headphones', sku: 'PWH-001', stock: 145, reorderPoint: 50, category: 'Electronics', status: 'in-stock' },
    { id: 2, name: 'Smart Fitness Tracker', sku: 'SFT-002', stock: 23, reorderPoint: 30, category: 'Electronics', status: 'low-stock' },
    { id: 3, name: 'Organic Cotton T-Shirt', sku: 'OCT-003', stock: 289, reorderPoint: 100, category: 'Apparel', status: 'in-stock' },
    { id: 4, name: 'Stainless Steel Water Bottle', sku: 'SWB-004', stock: 8, reorderPoint: 25, category: 'Home Goods', status: 'critical' },
    { id: 5, name: 'Wireless Charging Pad', sku: 'WCP-005', stock: 167, reorderPoint: 40, category: 'Electronics', status: 'in-stock' },
    { id: 6, name: 'Yoga Mat Premium', sku: 'YMP-006', stock: 12, reorderPoint: 20, category: 'Fitness', status: 'low-stock' },
    { id: 7, name: 'LED Desk Lamp', sku: 'LDL-007', stock: 0, reorderPoint: 15, category: 'Home Goods', status: 'out-of-stock' },
    { id: 8, name: 'Bluetooth Speaker', sku: 'BTS-008', stock: 94, reorderPoint: 30, category: 'Electronics', status: 'in-stock' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in-stock': return 'bg-green-100 text-green-700';
      case 'low-stock': return 'bg-yellow-100 text-yellow-700';
      case 'critical': return 'bg-orange-100 text-orange-700';
      case 'out-of-stock': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'in-stock': return 'In Stock';
      case 'low-stock': return 'Low Stock';
      case 'critical': return 'Critical';
      case 'out-of-stock': return 'Out of Stock';
      default: return status;
    }
  };

  const lowStockCount = products.filter(p => p.status === 'low-stock' || p.status === 'critical').length;
  const outOfStockCount = products.filter(p => p.status === 'out-of-stock').length;
  const totalValue = products.reduce((sum, p) => sum + (p.stock * 50), 0);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-800">Inventory Management</h1>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          Add Product
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Products</p>
              <p className="text-2xl font-semibold">{products.length}</p>
              <p className="text-sm text-gray-500 mt-1">
                Active SKUs
              </p>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <Package className="text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Low Stock Items</p>
              <p className="text-2xl font-semibold text-yellow-600">{lowStockCount}</p>
              <p className="text-sm text-gray-500 mt-1">
                Need attention
              </p>
            </div>
            <div className="bg-yellow-100 p-3 rounded-full">
              <AlertTriangle className="text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Out of Stock</p>
              <p className="text-2xl font-semibold text-red-600">{outOfStockCount}</p>
              <p className="text-sm text-gray-500 mt-1">
                Urgent restock
              </p>
            </div>
            <div className="bg-red-100 p-3 rounded-full">
              <TrendingDown className="text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Value</p>
              <p className="text-2xl font-semibold">${totalValue.toLocaleString()}</p>
              <p className="text-sm text-gray-500 mt-1">
                Inventory worth
              </p>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <Package className="text-green-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-medium">Product Inventory</h2>
          <div className="relative">
            <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search products..."
              className="pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="text-left text-xs text-gray-500 border-b">
                <th className="pb-3">Product</th>
                <th className="pb-3">SKU</th>
                <th className="pb-3">Category</th>
                <th className="pb-3">Stock</th>
                <th className="pb-3">Status</th>
                <th className="pb-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {products.map((product) => (
                <tr key={product.id} className="text-sm">
                  <td className="py-4 font-medium">{product.name}</td>
                  <td className="py-4 text-gray-600">{product.sku}</td>
                  <td className="py-4 text-gray-600">{product.category}</td>
                  <td className="py-4">
                    <div>
                      <div className="font-medium">{product.stock} units</div>
                      {product.stock < product.reorderPoint && (
                        <div className="text-xs text-orange-600 flex items-center mt-1">
                          <Clock size={12} className="mr-1" />
                          Reorder at {product.reorderPoint}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="py-4">
                    <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(product.status)}`}>
                      {getStatusText(product.status)}
                    </span>
                  </td>
                  <td className="py-4">
                    <button className="text-blue-600 hover:underline text-sm">Edit</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Inventory;
