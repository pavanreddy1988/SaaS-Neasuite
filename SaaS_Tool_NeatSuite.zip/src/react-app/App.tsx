import { useState } from 'react';
import '@/react-app/index.css';
import Sidebar from '@/react-app/components/Sidebar';
import Dashboard from '@/react-app/components/Dashboard';
import IntegrationsPanel from '@/react-app/components/IntegrationsPanel';
import Header from '@/react-app/components/Header';
import Sales from '@/react-app/pages/Sales';
import Inventory from '@/react-app/pages/Inventory';
import Finance from '@/react-app/pages/Finance';
import Reports from '@/react-app/pages/Reports';
import Settings from '@/react-app/pages/Settings';

export function App() {
  const [currentView, setCurrentView] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showIntegrations, setShowIntegrations] = useState(false);

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        collapsed={sidebarCollapsed} 
        setCollapsed={setSidebarCollapsed}
      />
      
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header 
          sidebarCollapsed={sidebarCollapsed} 
          setSidebarCollapsed={setSidebarCollapsed} 
          setShowIntegrations={setShowIntegrations}
        />
        
        <main className="flex-1 overflow-y-auto p-4">
          {currentView === 'dashboard' && <Dashboard />}
          {currentView === 'sales' && <Sales />}
          {currentView === 'inventory' && <Inventory />}
          {currentView === 'finance' && <Finance />}
          {currentView === 'reports' && <Reports />}
          {currentView === 'settings' && <Settings />}
        </main>
      </div>

      {showIntegrations && (
        <IntegrationsPanel onClose={() => setShowIntegrations(false)} />
      )}
    </div>
  );
}

export default App;
